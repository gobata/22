<?php get_header(); ?>


<div class="h1-outer">
<div class="wrap">
<h1 class="page-h1">404 Not Found.</h1>

</div>
<p style="font-size:16px;text-align:center;">お探しのページは移動したか、削除された可能性がございます。上部メニューより再度目的のページをお探し下さい。</p>
</div>







<?php get_footer();?>


