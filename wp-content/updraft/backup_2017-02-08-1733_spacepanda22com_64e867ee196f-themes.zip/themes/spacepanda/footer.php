<?php

?>

<div class="footer_wrap">
<footer>
<p>(c) 株式会社スペースパンダ22</p>
</footer>
</div><!--footer_wrap-->
<?php wp_footer(); ?>
</body>
</html>